package com.sijilordrati.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.webkit.GeolocationPermissions;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.os.Build;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 4101;
    private static final int SAVE_FILE = 4102;
    private static final int LOCATION_PERMISSION = 4103;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingName = "sijil-ordrati-backup.json";
    private String pendingData = "";
    private String pendingMime = "application/json";
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // The local bundled page loads Tesseract.js and language files from HTTPS only when OCR is used.
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep the app local; only allow HTTPS links to open outside the WebView.
                if (url != null && url.startsWith("https://")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                String[] accept = params.getAcceptTypes();
                if (accept != null && accept.length == 1 && !accept[0].isEmpty()) {
                    intent.setType(accept[0]);
                } else if (accept != null && accept.length > 1) {
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, accept);
                }
                try {
                    startActivityForResult(Intent.createChooser(intent, "اختار ملف أو صورة"), PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "تعذر فتح اختيار الملفات", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    pendingGeoCallback = callback;
                    pendingGeoOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
                } else {
                    callback.invoke(origin, true, false);
                }
            }

            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                return true;
            }
        });
        if (state == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(state);
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String name, String data, String mime) {
            runOnUiThread(() -> {
                pendingName = safeName(name);
                pendingData = data == null ? "" : data;
                pendingMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime.split(";")[0]);
                intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                try {
                    startActivityForResult(intent, SAVE_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر فتح نافذة حفظ الملف", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void callPhone(String phone) {
            runOnUiThread(() -> {
                String number = phone == null ? "" : phone.trim();
                if (number.isEmpty()) {
                    Toast.makeText(MainActivity.this, "اكتب رقم الهاتف أولاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openMap(double latitude, double longitude) {
            runOnUiThread(() -> {
                String coords = latitude + "," + longitude;
                // Android resolves every installed app that can handle geo navigation.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + coords + "?q=" + coords));
                try {
                    startActivity(Intent.createChooser(intent, "اختار تطبيق الملاحة"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ماكو تطبيق ملاحة يدعم فتح الموقع على جهازك", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    String jobName = "سجل أوردراتي - التسوية";
                    pm.print(jobName, webView.createPrintDocumentAdapter(jobName),
                            new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذرت الطباعة", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private String safeName(String name) {
        if (name == null || name.trim().isEmpty()) return "sijil-ordrati-export.txt";
        return name.replace("/", "_").replace("\\\\", "_");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (fileCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                        ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        } else if (requestCode == SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) out.write(pendingData.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "تم حفظ الملف", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show();
                }
            }
            pendingData = "";
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setMessage("تريد الخروج من سجل أوردراتي؟ بياناتك المحفوظة تبقى على الجهاز.")
            .setNegativeButton("إلغاء", (d, w) -> d.dismiss())
            .setPositiveButton("خروج", (d, w) -> finish())
            .show();
    }
}
